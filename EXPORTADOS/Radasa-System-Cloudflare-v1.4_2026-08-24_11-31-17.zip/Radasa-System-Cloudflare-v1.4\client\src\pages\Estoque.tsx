import { useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import Layout from "@/components/Layout";
import {
  useEstoque,
  useEstoqueProdutos,
  useEstoqueTipos,
  type CategoriaEstoque,
  type EstoqueMovimentacao,
  type EstoqueProduto,
  type TipoMovimentacaoEstoque,
} from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePicker } from "@/components/ui/date-picker";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  Boxes,
  Check,
  ChevronDown,
  Download,
  Eye,
  FileDown,
  FileText,
  PackagePlus,
  Pencil,
  Plus,
  Printer,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { formatBRL, formatDate } from "@/lib/exportUtils";

type ViewMode = "ESTOQUE" | "ENTRADAS" | "SAIDAS";
type CategoriaFiltro = "TODOS" | CategoriaEstoque;

const today = () => new Date().toISOString().slice(0, 10);
const emptyMovementForm = () => ({
  produtoId: "",
  tipo: "ENTRADA" as TipoMovimentacaoEstoque,
  quantidade: "",
  valorUnitario: "",
  data: today(),
  observacoes: "",
});

const emptyProductForm = (categoria: CategoriaEstoque) => ({
  nome: "",
  codigoInterno: "",
  categoria,
});

const fileToDataUrl = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Não foi possível ler o PDF."));
    reader.readAsDataURL(file);
  });

export default function Estoque() {
  const {
    items: tiposProduto,
    create: createTipoProduto,
    remove: removeTipoProduto,
  } = useEstoqueTipos();
  const {
    items: produtos,
    create: createProduto,
    update: updateProduto,
    remove: removeProduto,
  } = useEstoqueProdutos();
  const { movimentacoes, resumo, create, remove, refresh: refreshEstoque } = useEstoque();

  const [categoriaFiltro, setCategoriaFiltro] = useState<CategoriaFiltro>("TODOS");
  const [viewMode, setViewMode] = useState<ViewMode>("ESTOQUE");

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyMovementForm);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [viewing, setViewing] = useState<EstoqueMovimentacao | null>(null);
  const [pdfPreview, setPdfPreview] = useState<{ url: string; title: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [productOpen, setProductOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<EstoqueProduto | null>(null);
  const [productForm, setProductForm] = useState(() => emptyProductForm(""));
  const [savingProduct, setSavingProduct] = useState(false);

  const [typeManagerOpen, setTypeManagerOpen] = useState(false);
  const [newTypeName, setNewTypeName] = useState("");
  const [savingType, setSavingType] = useState(false);

  const categoriasEstoque = useMemo(
    () => tiposProduto.map((tipo) => tipo.nome),
    [tiposProduto],
  );

  const produtosFiltrados = useMemo(
    () => categoriaFiltro === "TODOS" ? produtos : produtos.filter((produto) => produto.categoria === categoriaFiltro),
    [produtos, categoriaFiltro],
  );
  const resumoFiltrado = useMemo(
    () => categoriaFiltro === "TODOS" ? resumo : resumo.filter((item) => item.produto.categoria === categoriaFiltro),
    [resumo, categoriaFiltro],
  );
  const movimentosFiltrados = useMemo(
    () => categoriaFiltro === "TODOS" ? movimentacoes : movimentacoes.filter((movimento) => movimento.produto.categoria === categoriaFiltro),
    [movimentacoes, categoriaFiltro],
  );
  const entradas = useMemo(
    () => movimentosFiltrados.filter((movimento) => movimento.tipo === "ENTRADA"),
    [movimentosFiltrados],
  );
  const saidas = useMemo(
    () => movimentosFiltrados.filter((movimento) => movimento.tipo === "SAIDA"),
    [movimentosFiltrados],
  );

  const totalEntradas = resumoFiltrado.reduce((total, item) => total + item.entradas, 0);
  const totalSaidas = resumoFiltrado.reduce((total, item) => total + item.saidas, 0);
  const totalEstoque = resumoFiltrado.reduce((total, item) => total + item.estoque, 0);

  const resetForm = () => {
    setForm(emptyMovementForm());
    setPdfFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const openCreateProduct = () => {
    const categoriaInicial = categoriaFiltro !== "TODOS" && categoriasEstoque.includes(categoriaFiltro)
      ? categoriaFiltro
      : categoriasEstoque[0];

    if (!categoriaInicial) {
      toast.error("Cadastre um tipo de produto antes de criar um produto no almoxarifado.");
      setTypeManagerOpen(true);
      return;
    }

    setEditingProduct(null);
    setProductForm(emptyProductForm(categoriaInicial));
    setProductOpen(true);
  };

  const openEditProduct = (produto: EstoqueProduto) => {
    setEditingProduct(produto);
    setProductForm({
      nome: produto.nome,
      codigoInterno: produto.codigoInterno,
      categoria: produto.categoria,
    });
    setProductOpen(true);
  };

  const submitProduct = async (event: FormEvent) => {
    event.preventDefault();
    if (savingProduct) return;

    setSavingProduct(true);
    try {
      if (editingProduct) {
        await updateProduto(editingProduct.id, productForm);
        toast.success("Produto do almoxarifado atualizado.");
      } else {
        const novoProduto = await createProduto(productForm);
        toast.success(`Produto criado com o código ${novoProduto.codigoInterno}.`);
      }
      setProductOpen(false);
      setEditingProduct(null);
      await refreshEstoque();
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Não foi possível salvar o produto do almoxarifado.");
    } finally {
      setSavingProduct(false);
    }
  };

  const deleteProduct = async (produto: EstoqueProduto) => {
    if (!window.confirm(`Excluir o produto "${produto.nome}" do almoxarifado?`)) return;
    try {
      await removeProduto(produto.id);
      await refreshEstoque();
      toast.success("Produto do almoxarifado excluído.");
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Não foi possível excluir o produto.");
    }
  };

  const submitTipoProduto = async (event: FormEvent) => {
    event.preventDefault();
    const nome = newTypeName.trim();
    if (!nome || savingType) return;

    setSavingType(true);
    try {
      const criado = await createTipoProduto({ nome });
      setNewTypeName("");
      setCategoriaFiltro(criado.nome);
      if (productOpen) {
        setProductForm((current) => ({ ...current, categoria: criado.nome }));
      }
      toast.success("Tipo de produto criado no almoxarifado.");
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Não foi possível criar o tipo de produto.");
    } finally {
      setSavingType(false);
    }
  };

  const deleteTipoProduto = async (tipo: { id: string; nome: string }) => {
    if (!window.confirm(`Remover o tipo de produto "${tipo.nome}"?`)) return;
    try {
      await removeTipoProduto(tipo.id);
      if (categoriaFiltro === tipo.nome) setCategoriaFiltro("TODOS");
      if (productForm.categoria === tipo.nome) {
        setProductForm((current) => ({ ...current, categoria: "" }));
      }
      toast.success("Tipo de produto removido.");
    } catch (error: any) {
      toast.error(error?.response?.data?.message || "Não foi possível remover o tipo de produto.");
    }
  };

  const openMovement = () => {
    if (!produtos.length) {
      toast.error('Nenhum produto cadastrado. Use o botão "Novo produto" para cadastrar um produto antes de registrar uma movimentação.');
      return;
    }

    if (!produtosFiltrados.length) {
      toast.error(`Nenhum produto do tipo ${categoriaFiltro} está cadastrado. Altere o filtro de tipo de produto ou cadastre um novo produto.`);
      return;
    }

    resetForm();
    setOpen(true);
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    try {
      const pdfUrl = pdfFile ? await fileToDataUrl(pdfFile) : undefined;
      await create({
        produtoId: form.produtoId,
        tipo: form.tipo,
        quantidade: Number(form.quantidade.replace(",", ".")),
        valorUnitario: Number(form.valorUnitario.replace(",", ".") || 0),
        data: form.data,
        observacoes: form.observacoes,
        pdfUrl,
        pdfName: pdfFile?.name,
      });
      toast.success(form.tipo === "ENTRADA" ? "Entrada registrada." : "Saída registrada.");
      setOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error?.response?.data?.message || error?.message || "Não foi possível registrar a movimentação.");
    }
  };

  const exportRows = viewMode === "ENTRADAS" ? entradas : viewMode === "SAIDAS" ? saidas : movimentosFiltrados;
  const categoryLabel = categoriaFiltro === "TODOS" ? "Todos os tipos" : categoriaFiltro;

  const exportCsv = () => {
    const headers = ["Data", "Produto", "Código", "Tipo", "Quantidade", "Valor unitário", "Valor total", "Observações", "NF PDF"];
    const rows = exportRows.map((item) => [
      formatDate(item.data),
      item.produto.nome,
      item.produto.codigoInterno,
      item.tipo === "ENTRADA" ? "Entrada" : "Saída",
      String(item.quantidade).replace(".", ","),
      String(item.valorUnitario).replace(".", ","),
      String(item.valorTotal).replace(".", ","),
      item.observacoes ?? "",
      item.pdfName ?? "",
    ]);
    const csv = [headers, ...rows]
      .map((row) => row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(";"))
      .join("\n");
    const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `almoxarifado_${categoryLabel
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, "_")
      .toLowerCase()}_${viewMode.toLowerCase()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const exportPdf = () => {
    const windowPrint = window.open("", "_blank", "width=1100,height=750");
    if (!windowPrint) {
      toast.error("Permita pop-ups para exportar o PDF.");
      return;
    }
    const rows = exportRows
      .map(
        (item) => `<tr><td>${formatDate(item.data)}</td><td>${escapeHtml(item.produto.nome)}</td><td>${escapeHtml(item.produto.codigoInterno)}</td><td>${item.tipo === "ENTRADA" ? "Entrada" : "Saída"}</td><td>${item.quantidade.toLocaleString("pt-BR")}</td><td>${formatBRL(item.valorUnitario)}</td><td>${formatBRL(item.valorTotal)}</td></tr>`,
      )
      .join("");
    windowPrint.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Relatório de almoxarifado</title><style>body{font-family:Arial,sans-serif;padding:28px;color:#111}h1{margin:0 0 4px;font-size:22px}p{margin:0 0 20px;color:#555}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #ccc;padding:8px;text-align:left}th{background:#f1f5f9}@media print{button{display:none}}</style></head><body><h1>Almoxarifado — ${escapeHtml(categoryLabel)}</h1><p>${viewMode === "ESTOQUE" ? "Todas as movimentações" : viewMode === "ENTRADAS" ? "Entradas" : "Saídas"}</p><table><thead><tr><th>Data</th><th>Produto</th><th>Código</th><th>Tipo</th><th>Quantidade</th><th>Valor unitário</th><th>Valor total</th></tr></thead><tbody>${rows || '<tr><td colspan="7">Nenhum registro.</td></tr>'}</tbody></table><script>window.onload=()=>window.print();</script></body></html>`);
    windowPrint.document.close();
  };

  return (
    <Layout>
      <div className="w-full min-w-0 space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold">Almoxarifado</h1>
            <p className="text-sm text-muted-foreground">
              Produtos do almoxarifado são cadastrados aqui e são independentes dos produtos da aba Cadastros.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={exportCsv}><FileDown className="mr-2 h-4 w-4" />Exportar CSV</Button>
            <Button variant="outline" onClick={exportPdf}><Printer className="mr-2 h-4 w-4" />Exportar PDF</Button>
            <Button onClick={openCreateProduct}><PackagePlus className="mr-2 h-4 w-4" />Novo produto</Button>
            <Button variant="outline" onClick={openMovement}><Plus className="mr-2 h-4 w-4" />Nova movimentação</Button>
          </div>
        </div>

        <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as ViewMode)}>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
            <TabsList className="grid w-full max-w-xl grid-cols-3">
              <TabsTrigger value="ESTOQUE">Estoque</TabsTrigger>
              <TabsTrigger value="ENTRADAS">Entrada</TabsTrigger>
              <TabsTrigger value="SAIDAS">Saída</TabsTrigger>
            </TabsList>

            <div className="w-full sm:w-[330px]">
              <Label className="mb-1.5 block text-xs text-muted-foreground">Tipo de produto</Label>
              <div className="flex gap-2">
                <Select value={categoriaFiltro} onValueChange={(value) => setCategoriaFiltro(value as CategoriaFiltro)}>
                  <SelectTrigger className="flex-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="TODOS">Todos os tipos</SelectItem>
                    {categoriasEstoque.map((category) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  size="icon"
                  variant="outline"
                  onClick={() => setTypeManagerOpen(true)}
                  title="Criar ou remover tipos de produto"
                  aria-label="Gerenciar tipos de produto"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-3 xl:gap-4">
            <Card title="Entradas" value={totalEntradas} icon={<ArrowDownToLine className="h-4 w-4" />} />
            <Card title="Saídas" value={totalSaidas} icon={<ArrowUpFromLine className="h-4 w-4" />} />
            <Card title="Saldo atual" value={totalEstoque} icon={<Boxes className="h-4 w-4" />} />
          </div>

          <TabsContent value="ESTOQUE" className="mt-4">
            <ResumoTable
              key={categoriaFiltro}
              rows={resumoFiltrado}
              onEditProduct={openEditProduct}
              onDeleteProduct={deleteProduct}
            />
          </TabsContent>
          <TabsContent value="ENTRADAS" className="mt-4">
            <MovimentacoesTable rows={entradas} onView={setViewing} onPdf={setPdfPreview} onRemove={remove} />
          </TabsContent>
          <TabsContent value="SAIDAS" className="mt-4">
            <MovimentacoesTable rows={saidas} onView={setViewing} onPdf={setPdfPreview} onRemove={remove} />
          </TabsContent>
        </Tabs>

        <Dialog open={productOpen} onOpenChange={(value) => { setProductOpen(value); if (!value) setEditingProduct(null); }}>
          <DialogContent className="sm:max-w-[520px]">
            <DialogHeader><DialogTitle>{editingProduct ? "Editar produto do almoxarifado" : "Novo produto do almoxarifado"}</DialogTitle></DialogHeader>
            <form onSubmit={submitProduct} className="space-y-4">
              <Field label="Nome do produto">
                <Input
                  required
                  value={productForm.nome}
                  onChange={(event) => setProductForm({ ...productForm, nome: event.target.value })}
                  placeholder="Ex: Cloro granulado"
                />
              </Field>
              <Field label="Código interno">
                <Input
                  value={editingProduct ? productForm.codigoInterno : ""}
                  disabled
                  placeholder={editingProduct ? undefined : "Gerado automaticamente: RAD-00001, RAD-00002..."}
                />
                {!editingProduct && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    O código será criado automaticamente ao cadastrar o produto.
                  </p>
                )}
              </Field>
              <Field label="Tipo de produto">
                <div className="flex gap-2">
                  <Select
                    value={productForm.categoria}
                    onValueChange={(value) => setProductForm({ ...productForm, categoria: value as CategoriaEstoque })}
                  >
                    <SelectTrigger className="flex-1"><SelectValue placeholder="Selecione o tipo" /></SelectTrigger>
                    <SelectContent>
                      {categoriasEstoque.map((category) => <SelectItem key={category} value={category}>{category}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Button
                    type="button"
                    size="icon"
                    variant="outline"
                    onClick={() => setTypeManagerOpen(true)}
                    title="Criar ou remover tipos de produto"
                    aria-label="Gerenciar tipos de produto"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </Field>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setProductOpen(false)}>Cancelar</Button>
                <Button type="submit" disabled={savingProduct || !productForm.categoria}>{savingProduct ? "Salvando..." : editingProduct ? "Salvar alterações" : "Cadastrar produto"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={typeManagerOpen} onOpenChange={(value) => { setTypeManagerOpen(value); if (!value) setNewTypeName(""); }}>
          <DialogContent className="sm:max-w-[540px]">
            <DialogHeader>
              <DialogTitle>Tipos de produto do almoxarifado</DialogTitle>
            </DialogHeader>
            <div className="space-y-5">
              <form onSubmit={submitTipoProduto} className="space-y-2">
                <Label htmlFor="novo-tipo-produto">Novo tipo de produto</Label>
                <div className="flex gap-2">
                  <Input
                    id="novo-tipo-produto"
                    value={newTypeName}
                    onChange={(event) => setNewTypeName(event.target.value)}
                    placeholder="Ex: EPI, Material elétrico, Limpeza..."
                    maxLength={80}
                  />
                  <Button type="submit" disabled={savingType || !newTypeName.trim()}>
                    <Plus className="mr-2 h-4 w-4" />
                    {savingType ? "Adicionando..." : "Adicionar"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Esta lista pertence somente ao Almoxarifado e não utiliza os produtos ou categorias da aba Cadastros.
                </p>
              </form>

              <div className="space-y-2">
                <Label>Tipos cadastrados</Label>
                <div className="max-h-[300px] space-y-2 overflow-y-auto rounded-lg border p-2">
                  {tiposProduto.map((tipo) => {
                    const quantidadeProdutos = produtos.filter((produto) => produto.categoria === tipo.nome).length;
                    return (
                      <div key={tipo.id} className="flex items-center justify-between gap-3 rounded-md border bg-muted/20 px-3 py-2">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{tipo.nome}</p>
                          <p className="text-xs text-muted-foreground">{quantidadeProdutos} produto(s) vinculado(s)</p>
                        </div>
                        <Button
                          type="button"
                          size="icon"
                          variant="ghost"
                          className="shrink-0 text-destructive hover:text-destructive"
                          onClick={() => void deleteTipoProduto(tipo)}
                          title={quantidadeProdutos > 0 ? "Remova ou altere os produtos vinculados antes de excluir este tipo" : "Remover tipo"}
                          aria-label={`Remover tipo ${tipo.nome}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    );
                  })}
                  {!tiposProduto.length && (
                    <div className="px-3 py-8 text-center text-sm text-muted-foreground">
                      Nenhum tipo de produto cadastrado.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={open} onOpenChange={(value) => { setOpen(value); if (!value) resetForm(); }}>
          <DialogContent className="sm:max-w-[620px]">
            <DialogHeader><DialogTitle>Nova movimentação</DialogTitle></DialogHeader>
            <form onSubmit={submit} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Tipo">
                  <Select value={form.tipo} onValueChange={(value) => setForm({ ...form, tipo: value as TipoMovimentacaoEstoque })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="ENTRADA">Entrada</SelectItem><SelectItem value="SAIDA">Saída</SelectItem></SelectContent>
                  </Select>
                </Field>
                <Field label="Data"><DatePicker value={form.data} onChange={(value) => setForm({ ...form, data: value })} placeholder="Selecione uma data" /></Field>
              </div>
              <Field label={categoriaFiltro === "TODOS" ? "Produto" : `Produto — ${categoriaFiltro}`}>
                <Select value={form.produtoId} onValueChange={(value) => setForm({ ...form, produtoId: value })}>
                  <SelectTrigger><SelectValue placeholder="Selecione o produto" /></SelectTrigger>
                  <SelectContent>
                    {produtosFiltrados.map((produto) => <SelectItem key={produto.id} value={produto.id}>{produto.nome} - {produto.codigoInterno}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Field label="Quantidade"><Input required value={form.quantidade} onChange={(event) => setForm({ ...form, quantidade: event.target.value })} placeholder="0" /></Field>
                <Field label={form.tipo === "SAIDA" ? "Valor unitário da saída *" : "Valor unitário"}><Input required={form.tipo === "SAIDA"} value={form.valorUnitario} onChange={(event) => setForm({ ...form, valorUnitario: event.target.value })} placeholder="0,00" /></Field>
              </div>
              <Field label="Observações"><Input value={form.observacoes} onChange={(event) => setForm({ ...form, observacoes: event.target.value })} /></Field>
              <Field label="Nota fiscal em PDF (opcional)">
                <input ref={fileInputRef} type="file" accept="application/pdf,.pdf" className="hidden" onChange={(event) => {
                  const file = event.target.files?.[0] ?? null;
                  if (file && file.type !== "application/pdf") { toast.error("Selecione um arquivo PDF."); return; }
                  setPdfFile(file);
                }} />
                {pdfFile ? (
                  <div className="flex items-center justify-between rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3">
                    <div className="flex min-w-0 items-center gap-3"><FileText className="h-5 w-5 shrink-0 text-emerald-500" /><div className="min-w-0"><p className="truncate text-sm font-medium">{pdfFile.name}</p><p className="text-xs text-muted-foreground">{(pdfFile.size / 1024).toFixed(1)} KB</p></div></div>
                    <div className="flex gap-1"><Button type="button" size="icon" variant="ghost" onClick={async () => setPdfPreview({ url: await fileToDataUrl(pdfFile), title: pdfFile.name })}><Eye className="h-4 w-4" /></Button><Button type="button" size="icon" variant="ghost" onClick={() => { setPdfFile(null); if (fileInputRef.current) fileInputRef.current.value = ""; }}><X className="h-4 w-4" /></Button></div>
                  </div>
                ) : <Button type="button" variant="outline" className="w-full" onClick={() => fileInputRef.current?.click()}><Upload className="mr-2 h-4 w-4" />Selecionar NF em PDF</Button>}
              </Field>
              <div className="flex justify-end"><Button type="submit" disabled={!form.produtoId}>Registrar</Button></div>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={!!viewing} onOpenChange={(value) => !value && setViewing(null)}>
          <DialogContent className="sm:max-w-[620px]">
            <DialogHeader><DialogTitle>Detalhes da movimentação</DialogTitle></DialogHeader>
            {viewing && <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm"><Detail label="Produto" value={`${viewing.produto.nome} - ${viewing.produto.codigoInterno}`} /><Detail label="Tipo" value={viewing.tipo === "ENTRADA" ? "Entrada" : "Saída"} /><Detail label="Data" value={formatDate(viewing.data)} /><Detail label="Quantidade" value={viewing.quantidade.toLocaleString("pt-BR")} /><Detail label="Valor unitário" value={formatBRL(viewing.valorUnitario)} /><Detail label="Valor total" value={formatBRL(viewing.valorTotal)} /></div>
              {viewing.observacoes && <Detail label="Observações" value={viewing.observacoes} />}
              {viewing.pdfUrl ? <div className="flex flex-wrap gap-2 border-t pt-4"><Button type="button" variant="outline" className="text-blue-600" onClick={() => setPdfPreview({ url: viewing.pdfUrl!, title: viewing.pdfName || "Nota fiscal" })}><Eye className="mr-2 h-4 w-4" />Visualizar PDF</Button><Button type="button" variant="outline" className="text-emerald-600" onClick={() => downloadPdf(viewing.pdfUrl!, viewing.pdfName || `nf_${viewing.id}.pdf`)}><Download className="mr-2 h-4 w-4" />Baixar PDF</Button></div> : <p className="text-sm text-muted-foreground">Nenhuma nota fiscal vinculada.</p>}
            </div>}
          </DialogContent>
        </Dialog>

        <Dialog open={!!pdfPreview} onOpenChange={(value) => !value && setPdfPreview(null)}>
          <DialogContent className="flex h-[95vh] w-[95vw] max-w-[95vw] flex-col overflow-hidden p-0">
            <DialogHeader className="flex-row items-center justify-between border-b px-5 py-3"><DialogTitle className="truncate pr-8">{pdfPreview?.title ?? "Visualizar PDF"}</DialogTitle></DialogHeader>
            {pdfPreview && <div className="min-h-0 flex-1 bg-muted/20"><object data={pdfPreview.url} type="application/pdf" className="h-full w-full" aria-label={pdfPreview.title}><div className="flex h-full flex-col items-center justify-center gap-3"><FileText className="h-12 w-12 text-muted-foreground" /><p>O navegador não conseguiu exibir este PDF.</p><Button onClick={() => downloadPdf(pdfPreview.url, pdfPreview.title)}><Download className="mr-2 h-4 w-4" />Baixar PDF</Button></div></object></div>}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}

type EstoqueResumoFilterKey = "produto" | "codigo" | "entradas" | "saidas" | "saldo" | "valorSaidas";

type EstoqueResumoFilters = Record<EstoqueResumoFilterKey, string>;

const emptyEstoqueResumoFilters: EstoqueResumoFilters = {
  produto: "",
  codigo: "",
  entradas: "",
  saidas: "",
  saldo: "",
  valorSaidas: "",
};

const estoqueResumoColumns: Array<{ key: EstoqueResumoFilterKey; label: string }> = [
  { key: "produto", label: "Produto" },
  { key: "codigo", label: "Código" },
  { key: "entradas", label: "Entradas" },
  { key: "saidas", label: "Saídas" },
  { key: "saldo", label: "Saldo" },
  { key: "valorSaidas", label: "Valor das saídas" },
];

const normalizeFilterText = (value: unknown) =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR")
    .trim();

function ResumoTable({
  rows,
  onEditProduct,
  onDeleteProduct,
}: {
  rows: ReturnType<typeof useEstoque>["resumo"];
  onEditProduct: (produto: EstoqueProduto) => void;
  onDeleteProduct: (produto: EstoqueProduto) => Promise<void>;
}) {
  const [columnFilters, setColumnFilters] = useState<EstoqueResumoFilters>(emptyEstoqueResumoFilters);
  const [activeColumnFilter, setActiveColumnFilter] = useState<EstoqueResumoFilterKey | null>(null);
  const [columnFilterSearch, setColumnFilterSearch] = useState("");

  const displayValue = (row: (typeof rows)[number], key: EstoqueResumoFilterKey) => {
    if (key === "produto") return row.produto.nome;
    if (key === "codigo") return row.produto.codigoInterno;
    if (key === "entradas") return row.entradas.toLocaleString("pt-BR");
    if (key === "saidas") return row.saidas.toLocaleString("pt-BR");
    if (key === "saldo") return row.estoque.toLocaleString("pt-BR");
    return formatBRL(row.valorSaidas);
  };

  const filteredRows = useMemo(
    () => rows.filter((row) =>
      estoqueResumoColumns.every(({ key }) => !columnFilters[key] || displayValue(row, key) === columnFilters[key]),
    ),
    [rows, columnFilters],
  );

  const optionsFor = (key: EstoqueResumoFilterKey) =>
    Array.from(new Set(rows.map((row) => displayValue(row, key))))
      .filter(Boolean)
      .filter((option) => normalizeFilterText(option).includes(normalizeFilterText(columnFilterSearch)))
      .sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true }));

  const hasFilters = estoqueResumoColumns.some(({ key }) => Boolean(columnFilters[key]));

  return (
    <div className="space-y-2">
      {hasFilters && (
        <div className="flex justify-end">
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => setColumnFilters(emptyEstoqueResumoFilters)}
          >
            <X className="mr-2 h-4 w-4" />Limpar filtros
          </Button>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border bg-card">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="bg-muted/30">
            <tr>
              {estoqueResumoColumns.map((column) => {
                const active = Boolean(columnFilters[column.key]);
                const options = optionsFor(column.key);

                return (
                  <th key={column.key} className="px-4 py-3 font-semibold">
                    <Popover
                      open={activeColumnFilter === column.key}
                      onOpenChange={(open) => {
                        setActiveColumnFilter(open ? column.key : null);
                        setColumnFilterSearch("");
                      }}
                    >
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          className={`flex w-full items-center gap-1 rounded-sm text-left outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-primary ${active ? "text-primary" : "text-muted-foreground"}`}
                          title={`Filtrar por ${column.label}`}
                        >
                          <span>{column.label}</span>
                          <ChevronDown className="h-4 w-4 shrink-0" />
                        </button>
                      </PopoverTrigger>

                      <PopoverContent align="start" className="w-80 p-0">
                        <div className="border-b p-3">
                          <Input
                            value={columnFilterSearch}
                            onChange={(event) => setColumnFilterSearch(event.target.value)}
                            placeholder={`Pesquisar ${column.label.toLocaleLowerCase("pt-BR")}...`}
                            autoFocus
                          />
                        </div>

                        <div className="max-h-60 overflow-y-auto p-2">
                          {options.length === 0 ? (
                            <p className="py-4 text-center text-xs text-muted-foreground">Nenhuma opção encontrada.</p>
                          ) : options.map((option) => (
                            <button
                              type="button"
                              key={option}
                              onClick={() => {
                                setColumnFilters((current) => ({ ...current, [column.key]: option }));
                                setActiveColumnFilter(null);
                              }}
                              className={`flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm hover:bg-muted ${columnFilters[column.key] === option ? "bg-primary/10 text-primary" : ""}`}
                            >
                              <span className="truncate">{option}</span>
                              {columnFilters[column.key] === option && <Check className="h-4 w-4" />}
                            </button>
                          ))}
                        </div>

                        <div className="flex gap-2 border-t p-3">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1"
                            onClick={() => setColumnFilters((current) => ({ ...current, [column.key]: "" }))}
                          >
                            Limpar
                          </Button>
                          <Button size="sm" className="flex-1" onClick={() => setActiveColumnFilter(null)}>OK</Button>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </th>
                );
              })}
              <th className="px-4 py-3 text-left text-muted-foreground">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filteredRows.map((row) => (
              <tr key={row.produto.id} className="border-t">
                <td className="px-4 py-3 font-medium">{row.produto.nome}</td>
                <td className="px-4 py-3">{row.produto.codigoInterno}</td>
                <td className="px-4 py-3 text-emerald-500">{row.entradas.toLocaleString("pt-BR")}</td>
                <td className="px-4 py-3 text-amber-500">{row.saidas.toLocaleString("pt-BR")}</td>
                <td className="px-4 py-3 font-bold text-primary">{row.estoque.toLocaleString("pt-BR")}</td>
                <td className="px-4 py-3">{formatBRL(row.valorSaidas)}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" className="text-blue-600" onClick={() => onEditProduct(row.produto)} title="Editar produto"><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" className="text-destructive" onClick={() => void onDeleteProduct(row.produto)} title="Excluir produto"><Trash2 className="h-4 w-4" /></Button>
                  </div>
                </td>
              </tr>
            ))}
            {!filteredRows.length && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">
                  {hasFilters ? "Nenhum produto corresponde aos filtros da tabela." : "Nenhum produto cadastrado para o filtro selecionado."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MovimentacoesTable({ rows, onView, onPdf, onRemove }: { rows: EstoqueMovimentacao[]; onView: (item: EstoqueMovimentacao) => void; onPdf: (item: { url: string; title: string }) => void; onRemove: (id: string) => Promise<void> }) {
  return <div className="overflow-x-auto rounded-xl border bg-card"><table className="w-full min-w-[840px] text-sm"><thead className="bg-muted/30"><tr>{["Data", "Produto", "Quantidade", "Valor unitário", "Valor total", "NF", "Ações"].map((header) => <th key={header} className="px-4 py-3 text-left text-muted-foreground">{header}</th>)}</tr></thead><tbody>{rows.map((item) => <tr key={item.id} className="border-t"><td className="px-4 py-3">{formatDate(item.data)}</td><td className="px-4 py-3 font-medium">{item.produto.nome} - {item.produto.codigoInterno}</td><td className="px-4 py-3">{item.quantidade.toLocaleString("pt-BR")}</td><td className="px-4 py-3">{formatBRL(item.valorUnitario)}</td><td className="px-4 py-3">{formatBRL(item.valorTotal)}</td><td className="px-4 py-3">{item.pdfUrl ? <button className="text-blue-600 hover:underline" onClick={() => onPdf({ url: item.pdfUrl!, title: item.pdfName || "Nota fiscal" })}>Visualizar</button> : <span className="text-muted-foreground">—</span>}</td><td className="px-4 py-3"><div className="flex gap-1"><Button size="icon" variant="ghost" className="text-blue-600" onClick={() => onView(item)}><Eye className="h-4 w-4" /></Button>{item.pdfUrl && <Button size="icon" variant="ghost" className="text-emerald-600" onClick={() => downloadPdf(item.pdfUrl!, item.pdfName || `nf_${item.id}.pdf`)}><Download className="h-4 w-4" /></Button>}<Button size="icon" variant="ghost" className="text-destructive" onClick={async () => { try { await onRemove(item.id); toast.success("Movimentação removida."); } catch (error: any) { toast.error(error?.response?.data?.message || "Não foi possível remover."); } }}><Trash2 className="h-4 w-4" /></Button></div></td></tr>)}{!rows.length && <tr><td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">Nenhuma movimentação registrada.</td></tr>}</tbody></table></div>;
}

function downloadPdf(url: string, filename: string) {
  const link = document.createElement("a");
  link.href = url;
  link.download = filename.toLowerCase().endsWith(".pdf") ? filename : `${filename}.pdf`;
  link.click();
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character] ?? character);
}

function Card({ title, value, icon }: { title: string; value: number; icon: ReactNode }) {
  return <div className="rounded-xl border bg-card p-5"><div className="flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground">{icon}{title}</div><div className="mt-2 text-2xl font-bold">{value.toLocaleString("pt-BR")}</div></div>;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>;
}

function Detail({ label, value }: { label: string; value: string }) {
  return <div><p className="text-xs text-muted-foreground">{label}</p><p className="font-medium">{value}</p></div>;
}
